/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz3;

/**
 *
 * @author kpham
 */
public class Showmenu {

    public Showmenu() {
    }
    public void menu(){
        System.out.println("\n=== Number Base Converter ===");
            System.out.println("1. Binary");
            System.out.println("2. Decimal");
            System.out.println("3. Hexadecimal");
            System.out.println("4. Exit");
    }
}
