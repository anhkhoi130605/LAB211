/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz4;

/**
 *
 * @author kpham
 */
public class menu {
    public void showMenu(){
       System.out.println("======== Equation Solver Program ========");
        System.out.println("1. Solve Linear Equation (ax + b = 0)");
        System.out.println("2. Solve Quadratic Equation (ax^2 + bx + c = 0)");
        System.out.println("3. Display even, odd, and perfect square numbers from coefficients");
        System.out.println("4. Exit");
        System.out.print("Please choose an option: ");
    }
}
